# Amazon_Task2
Test Scenario For Amazon
- Open amazon.com
-	Open today's deals
-	from the left side filters select "Headphones" and "grocery"
-	from the discount part choose "10% off or more"
-	go to the fourth page then select any item and add it to the cart

